# UrbanSound8K Data Preprocessing
## For Models

Load `preprocessed_data/` with:

```python
import numpy as np

# Load one fold
X_train = np.load('preprocessed_data/fold_1/mfcc/X_train.npy')
y_train = np.load('preprocessed_data/fold_1/y_train.npy')
X_val = np.load('preprocessed_data/fold_1/mfcc/X_val.npy')
y_val = np.load('preprocessed_data/fold_1/y_val.npy')
X_test = np.load('preprocessed_data/fold_1/mfcc/X_test.npy')
y_test = np.load('preprocessed_data/fold_1/y_test.npy')

print(f"Train shape: {X_train.shape}")  # (7079, 40, 173)
print(f"Unique classes: {len(np.unique(y_train))}")  # 10
```

### For CNN:
```python
# Add channel dimension for Conv2D
X_train = np.expand_dims(X_train, axis=-1)  # (samples, 40, 173, 1)
```

### For RNN:
```python
# Transpose for LSTM input
X_train = np.transpose(X_train, (0, 2, 1))  # (samples, 173, 40)
```

### 10-Fold CV Loop:
```python
for fold in range(1, 11):
    X_train = np.load(f'preprocessed_data/fold_{fold}/mfcc/X_train.npy')
    y_train = np.load(f'preprocessed_data/fold_{fold}/y_train.npy')
    # ... train model ...
```

## Configuration

In `preprocess_urbansound.py`, can be adjusted:

```python
# What to extract (set False to skip and save space)
EXTRACT_MFCC = True          # ~2GB - RECOMMENDED for CNN
EXTRACT_MEL_SPEC = True      # ~2GB - Alternative for CNN  
EXTRACT_RAW = False          # ~8GB - For RNN (optional, large!)

# Data augmentation (training only)
AUGMENT_TRAINING = True      # Time stretch, pitch shift, noise
```

## Dataset Info

- **Classes:** 10 (air_conditioner, car_horn, children_playing, dog_bark, drilling, engine_idling, gun_shot, jackhammer, siren, street_music)
- **Total samples:** 8,732
- **Per fold:** ~873 samples
- **Splits:** 8 folds train (~7079), 1 fold val (~873), 1 fold test (~873)

## What went into preprocessing

1. **Normalizes audio:** Resamples to 22,050 Hz, fixes duration to 4 seconds
2. **Extracts features:** 
   - MFCC: 40 coefficients × 173 time frames (good for CNN)
   - Mel spectrogram: 128 bins × 173 frames (alternative)
   - Raw audio: 88,200 samples (optional, for RNN)
3. **Augments training data:** Random time stretch, pitch shift, noise
4. **Creates 10 folds:** Each fold becomes test once, validation once

## Estimated Results

- **CNN on MFCC:** 75-85% accuracy
- **RNN on sequences:** 70-80% accuracy
