import numpy as np
import tensorflow as tf
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow.keras import layers, models, callbacks, optimizers, regularizers
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.utils.class_weight import compute_class_weight
from pathlib import Path

# ======================================================
# CONFIG (Parâmetros Focados em Performance)
# ======================================================
DATA_DIR = Path("./preprocessed_data")
RESULTS_DIR = Path("./results_optimized_v2") # Nova pasta para os novos resultados
FEATURE_TYPE = "mel_spec" 
NUM_FOLDS = 10
NUM_CLASSES = 10
EPOCHS = 80 # Aumentei um pouco (EarlyStopping vai controlar)
BATCH_SIZE = 32
SEED = 42
L2_REGULARIZATION_RATE = 1e-4 # Taxa de L2 (Regularização)
INITIAL_LR = 1e-3 # Learning Rate inicial
# Parâmetros de Early Stopping e LR Reduction
ES_PATIENCE = 10 
RLRP_PATIENCE = 4 # Reduzi para reagir mais rápido a platôs

# Criar os diretorios com resultados
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# Configurar as seeds para reprodutibilidade
tf.random.set_seed(SEED)
np.random.seed(SEED)

# ======================================================
# UTILS: Plotting (Inalterado)
# ======================================================
def plot_history(history, fold):
    """Gera gráficos de Loss e Accuracy"""
    fig, ax = plt.subplots(1, 2, figsize=(12, 4))
    
    # Accuracy
    ax[0].plot(history.history['accuracy'], label='Train')
    ax[0].plot(history.history['val_accuracy'], label='Val')
    ax[0].set_title(f'Model Accuracy - Fold {fold}')
    ax[0].set_ylabel('Accuracy')
    ax[0].set_xlabel('Epoch')
    ax[0].legend(loc='lower right')
    ax[0].grid(True, alpha=0.3)
    
    # Loss
    ax[1].plot(history.history['loss'], label='Train')
    ax[1].plot(history.history['val_loss'], label='Val')
    ax[1].set_title(f'Fold {fold}-Loss')
    ax[1].set_ylabel('Loss')
    ax[1].set_xlabel('Epoch')
    ax[1].legend(loc='upper right')
    ax[1].grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(RESULTS_DIR / f"history_fold_{fold}.png", dpi=100)
    plt.close(fig)


def plot_confusion_matrix(y_true, y_pred, fold, class_names=None):
    """Gera e guarda a matriz de confusão"""
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(10, 8))
    
    # Se tiver nomes de classes, use-os
    if class_names is not None:
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False,
                    xticklabels=class_names, yticklabels=class_names)
    else:
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False)

    plt.title(f'Confusion Matrix - Fold {fold}')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    plt.savefig(RESULTS_DIR / f"cm_fold_{fold}.png", dpi=100)
    plt.close()

# ======================================================
# Load fold data (Inalterado, mas Nota de Augmentation)
# ======================================================

# O código assume que X_train, y_train já contêm dados pré-processados e aumentados
# (mel_spec normalizados globalmente).
def load_fold_data(fold):
    fold_dir = DATA_DIR / f"fold_{fold}"

    try:
        X_train = np.load(fold_dir / FEATURE_TYPE / "X_train.npy")
        X_val   = np.load(fold_dir / FEATURE_TYPE / "X_val.npy")
        X_test  = np.load(fold_dir / FEATURE_TYPE / "X_test.npy")
    except FileNotFoundError:
        raise FileNotFoundError(f"Não encontrei dados para '{FEATURE_TYPE}' em {fold_dir}. Verificar se a pasta existe ou altera o FEATURE_TYPE no código.")
    
    y_train = np.load(fold_dir / "y_train.npy")
    y_val   = np.load(fold_dir / "y_val.npy")
    y_test  = np.load(fold_dir / "y_test.npy")

    # Adicionar dimensão do canal (H, W, 1)
    X_train = X_train[..., np.newaxis]
    X_val   = X_val[..., np.newaxis]
    X_test  = X_test[..., np.newaxis]   

    return X_train, y_train, X_val, y_val, X_test, y_test

# ======================================================
# Build IMPROVED CNN model (MAXIMIZADO)
# ======================================================
def build_ultra_optimized_cnn(input_shape, num_classes=NUM_CLASSES):
    """
    Constrói o modelo CNN 2D otimizado com ELU, BatchNormalization, L2 Regularization,
    e arquitetura simplificada pós-Global Average Pooling.
    """
    model = models.Sequential()
    l2_reg = regularizers.l2(L2_REGULARIZATION_RATE) # Taxa de L2

    # --- Bloco Convolucional 1 ---
    # Kernel: he_normal é bom para ELU/ReLU
    model.add(layers.Conv2D(32, (3,3), padding='same', input_shape=input_shape, 
                            kernel_initializer='he_normal', kernel_regularizer=l2_reg))
    model.add(layers.BatchNormalization())
    model.add(layers.Activation('elu')) # Melhor que ReLU
    model.add(layers.MaxPooling2D((2,2)))
    model.add(layers.Dropout(0.1))

    # --- Bloco Convolucional 2 ---
    model.add(layers.Conv2D(64, (3,3), padding='same', kernel_initializer='he_normal', kernel_regularizer=l2_reg))
    model.add(layers.BatchNormalization())
    model.add(layers.Activation('elu'))
    model.add(layers.MaxPooling2D((2,2)))
    model.add(layers.Dropout(0.1))

    # --- Bloco Convolucional 3 ---
    model.add(layers.Conv2D(128, (3,3), padding='same', kernel_initializer='he_normal', kernel_regularizer=l2_reg))
    model.add(layers.BatchNormalization())
    model.add(layers.Activation('elu'))
    model.add(layers.MaxPooling2D((2,2)))
    model.add(layers.Dropout(0.2))
    
    # --- Bloco Convolucional 4 (Mais profundo) ---
    model.add(layers.Conv2D(256, (3,3), padding='same', kernel_initializer='he_normal', kernel_regularizer=l2_reg))
    model.add(layers.BatchNormalization())
    model.add(layers.Activation('elu'))
    
    # Substitui Flatten + Dense Gigante
    model.add(layers.GlobalAveragePooling2D()) 
    model.add(layers.Dropout(0.3)) # Aumento do dropout aqui (após GAP)

    # --- Camada Densa Final (Simplificada) ---
    # Reduzindo o número de camadas densas para evitar overfitting excessivo pós-GAP
    
    #  Uma camada densa pequena antes da saída
    # model.add(layers.Dense(64, kernel_initializer='he_normal', kernel_regularizer=l2_reg))
    # model.add(layers.BatchNormalization())
    # model.add(layers.Activation('elu'))
    # model.add(layers.Dropout(0.3))
    
    # --- Output ---
    model.add(layers.Dense(num_classes, activation='softmax'))

    # Otimizador com LR ajustável
    model.compile(
        optimizer=optimizers.Adam(learning_rate=INITIAL_LR),
        loss='sparse_categorical_crossentropy', # Mantido, se labels forem inteiros
        metrics=['accuracy']
    )

    return model

# ======================================================
# Train single fold
# ======================================================
def train_fold(fold):
    print(f"\n======================")
    print(f" TRAINING FOLD {fold}")
    print(f"======================")

    # Carregar os dados
    try:
        X_train, y_train, X_val, y_val, X_test, y_test = load_fold_data(fold)
    except FileNotFoundError as e:
        print(e)
        return None 
    
    # Carregar nomes das classes para o relatório de classificação, se existirem (assumindo que não)
    class_names = [str(i) for i in range(NUM_CLASSES)]
    
    input_shape = X_train.shape[1:] 
    print(X_train.shape)
    model = build_ultra_optimized_cnn(input_shape)

    # Calcular pesos das classes para lidar com desbalanceamento (Essencial)
    class_weights = compute_class_weight(
        'balanced',
        classes=np.unique(y_train),
        y=y_train
    )
    class_weights_dict = {i: class_weights[i] for i in range(len(class_weights))}
    
    # Callbacks (Paciência ajustada para melhor convergência)
    checkpoint_path = RESULTS_DIR / f"best_model_fold{fold}.keras"
    checkpoint = callbacks.ModelCheckpoint(
        checkpoint_path,
        monitor='val_accuracy',
        save_best_only=True,
        verbose=0 # Mudei para 0 para output mais limpo
    )
    # Reduzir LR se não melhorar
    reduce_lr = callbacks.ReduceLROnPlateau(
        monitor='val_loss', factor=0.5, patience=RLRP_PATIENCE, verbose=1, min_lr=1e-6
    )
    # Parar cedo se não melhorar
    early_stop = callbacks.EarlyStopping(
        monitor='val_loss', patience=ES_PATIENCE, restore_best_weights=True, verbose=1
    )

    # Train
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        class_weight=class_weights_dict,
        callbacks=[checkpoint, reduce_lr, early_stop],
        verbose=2 # 1 para log por época, 2 para um log mais limpo
    )
    
    # Gerar gráficos de treino
    plot_history(history, fold)

    # Evaluate on test split
    print(f"Evaluating Fold {fold}...")
    # Carregar o melhor modelo salvo
    try:
        best_model = models.load_model(checkpoint_path)
    except Exception as e:
        print(f"Erro ao carregar o melhor modelo: {e}. Usando o modelo treinado.")
        best_model = model
    
    preds_probs = best_model.predict(X_test, verbose=0)
    preds = np.argmax(preds_probs, axis=1)

    # Relatório e Matriz de Confusão
    print("\nClassification Report:")
    print(classification_report(y_test, preds, digits=4, target_names=class_names))
    
    plot_confusion_matrix(y_test, preds, fold, class_names=class_names)

    acc = np.mean(preds == y_test)
    print(f"Fold {fold} Test Accuracy = {acc:.4f}")

    return acc

# ======================================================
# Run all folds
# ======================================================
if __name__ == "__main__":
    # Verificar se as bibliotecas de plot existem
    try:
        import seaborn
        import matplotlib
    except ImportError:
        print("AVISO: Instala seaborn e matplotlib para veres os gráficos!")
        print("pip install seaborn matplotlib")

    accuracies = []
    for fold in range(1, NUM_FOLDS+1):
        acc = train_fold(fold)
        if acc is not None:
            accuracies.append(acc)

    if not accuracies:
        print("\nO treino não pôde ser iniciado. Verifique o seu diretório DATA_DIR e FEATURE_TYPE.")
        exit()
        
    print("\n======================")
    print(" 10-FOLD CV RESULTS (ULTRA OPTIMIZED MODEL)")
    print("======================")
    for i, a in enumerate(accuracies, 1):
        print(f"Fold {i}: acc = {a:.4f}")
    
    mean_acc = np.mean(accuracies)
    std_acc = np.std(accuracies)
    
    print(f"\nMean accuracy = {mean_acc:.4f}")
    print(f"Std = {std_acc:.4f}")
    
    # Salvar resumo final num ficheiro de texto
    with open(RESULTS_DIR / "final_results.txt", "w") as f:
        f.write(f"Mean Accuracy: {mean_acc:.4f}\n")
        f.write(f"Std Dev: {std_acc:.4f}\n")
        f.write(f"Results per fold: {accuracies}\n")